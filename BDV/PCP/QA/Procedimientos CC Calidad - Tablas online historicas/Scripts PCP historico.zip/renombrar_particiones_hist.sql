-- =====================================================
-- SCRIPT COMPLETO: Renombrado autom�tico de particiones HIST
-- Esquema: PCPH
-- Tablas: CREDITS_HIST, CREDITS_CREDITO_INMEDIATO_HIST, ORDEN_DETAIL_HIST,
--         ORDEN_HIST, DEBITS_HIST, TRACK_ORDEN_HIST, DATOS_MOVIMIENTOS_HIST,
--         LOGS_RESP_PROC_PCP1_HIST
-- Descripci�n: Renombra particiones SYS_Pxxx a:
--   - Para fechas: <TABLA>_YYYYMM (mensual)
--   - Para num�rico: <TABLA>_<VALOR_INICIAL>
-- =====================================================

SET SERVEROUTPUT ON;
SET FEEDBACK ON;

-- =====================================================
-- 1. Creaci�n del procedimiento principal
-- =====================================================

CREATE OR REPLACE PROCEDURE PCPH.RENOMBRAR_PARTICIONES_HIST IS
    /*
    Prop�sito: Renombra autom�ticamente las particiones con nombres gen�ricos (SYS_Pxxxx)
    de las tablas especificadas en el esquema PCPH.
    
    Tablas procesadas:
      - CREDITS_HIST (fecha mensual por PROCESS_DATE)
      - CREDITS_CREDITO_INMEDIATO_HIST (fecha mensual por FECHA_REGISTRO)
      - ORDEN_DETAIL_HIST (num�rico por ID_ORDEN - intervalo 1,000,000)
      - ORDEN_HIST (fecha mensual por DATE_VALUE)
      - DEBITS_HIST (fecha mensual por PROCESS_DATE)
      - TRACK_ORDEN_HIST (num�rico por ID_TRACK_ORDEN - intervalo 100,000)
      - DATOS_MOVIMIENTOS_HIST (fecha mensual por FECHA_REGISTRO)
      - LOGS_RESP_PROC_PCP1_HIST (fecha mensual por FECHA_REGISTRO)
    */
    
    TYPE t_tables IS TABLE OF VARCHAR2(35);
    v_tables t_tables := t_tables('CREDITS_HIST',
                                   'CREDITS_CREDITO_INMEDIATO_HIST',
                                   'ORDEN_DETAIL_HIST',
                                   'ORDEN_HIST',
                                   'DEBITS_HIST',
                                   'TRACK_ORDEN_HIST',
                                   'DATOS_MOVIMIENTOS_HIST',
                                   'LOGS_RESP_PROC_PCP1_HIST');
    
    v_nuevo_nombre VARCHAR2(100);
    v_contador_total NUMBER := 0;
    v_contador_tabla NUMBER;
    v_high_value VARCHAR2(4000);
    v_cursor NUMBER;
    v_ignore NUMBER;
    v_fecha DATE;
    v_valor_numerico NUMBER;
    
    -- Funci�n para obtener HIGH_VALUE como VARCHAR2
    FUNCTION get_high_value(p_table_name VARCHAR2, p_partition_name VARCHAR2) RETURN VARCHAR2 IS
        v_high_value VARCHAR2(4000);
        v_cursor NUMBER;
        v_ignore NUMBER;
    BEGIN
        v_cursor := DBMS_SQL.OPEN_CURSOR;
        DBMS_SQL.PARSE(v_cursor, 'SELECT HIGH_VALUE FROM USER_TAB_PARTITIONS 
                                  WHERE TABLE_NAME = :T AND PARTITION_NAME = :P', DBMS_SQL.NATIVE);
        DBMS_SQL.BIND_VARIABLE(v_cursor, ':T', p_table_name);
        DBMS_SQL.BIND_VARIABLE(v_cursor, ':P', p_partition_name);
        DBMS_SQL.DEFINE_COLUMN(v_cursor, 1, v_high_value, 4000);
        v_ignore := DBMS_SQL.EXECUTE_AND_FETCH(v_cursor);
        DBMS_SQL.COLUMN_VALUE(v_cursor, 1, v_high_value);
        DBMS_SQL.CLOSE_CURSOR(v_cursor);
        RETURN v_high_value;
    EXCEPTION
        WHEN OTHERS THEN
            IF DBMS_SQL.IS_OPEN(v_cursor) THEN
                DBMS_SQL.CLOSE_CURSOR(v_cursor);
            END IF;
            RETURN NULL;
    END get_high_value;
    
    -- Funci�n para extraer fecha del HIGH_VALUE
    FUNCTION extraer_fecha_from_high_value(p_high_value VARCHAR2) RETURN DATE IS
        v_fecha DATE;
        v_fecha_str VARCHAR2(200);
        v_pos NUMBER;
    BEGIN
        IF p_high_value IS NULL THEN
            RETURN NULL;
        END IF;
        
        -- Buscar TO_DATE en el HIGH_VALUE
        v_pos := INSTR(UPPER(p_high_value), 'TO_DATE');
        IF v_pos > 0 THEN
            -- Extraer la fecha entre comillas
            v_pos := INSTR(p_high_value, '''');
            IF v_pos > 0 THEN
                v_fecha_str := SUBSTR(p_high_value, v_pos + 1);
                v_pos := INSTR(v_fecha_str, '''');
                IF v_pos > 0 THEN
                    v_fecha_str := SUBSTR(v_fecha_str, 1, v_pos - 1);
                    -- Intentar convertir a fecha
                    BEGIN
                        v_fecha := TO_DATE(v_fecha_str, 'YYYY-MM-DD');
                        RETURN v_fecha;
                    EXCEPTION
                        WHEN OTHERS THEN
                            BEGIN
                                v_fecha := TO_DATE(v_fecha_str, 'DD-MM-YYYY');
                                RETURN v_fecha;
                            EXCEPTION
                                WHEN OTHERS THEN
                                    RETURN NULL;
                            END;
                    END;
                END IF;
            END IF;
        END IF;
        
        -- Si no hay TO_DATE, intentar como fecha directa
        BEGIN
            v_fecha := TO_DATE(p_high_value, 'YYYY-MM-DD');
            RETURN v_fecha;
        EXCEPTION
            WHEN OTHERS THEN
                RETURN NULL;
        END;
    END extraer_fecha_from_high_value;
    
    -- Funci�n para extraer valor num�rico del HIGH_VALUE
    FUNCTION extraer_numero_from_high_value(p_high_value VARCHAR2) RETURN NUMBER IS
        v_num_str VARCHAR2(100);
        v_pos NUMBER;
    BEGIN
        IF p_high_value IS NULL THEN
            RETURN NULL;
        END IF;
        
        -- Buscar el n�mero despu�s de "VALUES LESS THAN ("
        v_pos := INSTR(UPPER(p_high_value), 'VALUES LESS THAN (');
        IF v_pos > 0 THEN
            v_num_str := SUBSTR(p_high_value, v_pos + 19);
            v_pos := INSTR(v_num_str, ')');
            IF v_pos > 0 THEN
                v_num_str := SUBSTR(v_num_str, 1, v_pos - 1);
                v_num_str := REPLACE(v_num_str, ' ', '');
                -- Extraer solo n�meros
                v_num_str := REGEXP_SUBSTR(v_num_str, '[0-9]+');
                IF v_num_str IS NOT NULL THEN
                    RETURN TO_NUMBER(v_num_str);
                END IF;
            END IF;
        END IF;
        
        -- Si no encuentra, buscar cualquier n�mero en el string
        v_num_str := REGEXP_SUBSTR(p_high_value, '[0-9]+');
        IF v_num_str IS NOT NULL THEN
            RETURN TO_NUMBER(v_num_str);
        END IF;
        
        RETURN NULL;
    END extraer_numero_from_high_value;
    
    -- Funci�n para determinar si la partici�n es por fecha o num�rica seg�n la tabla
    FUNCTION es_tabla_fecha(p_table_name VARCHAR2) RETURN BOOLEAN IS
    BEGIN
        -- Tablas particionadas por FECHA
        IF p_table_name IN ('CREDITS_HIST', 
                            'CREDITS_CREDITO_INMEDIATO_HIST',
                            'ORDEN_HIST', 
                            'DEBITS_HIST',
                            'DATOS_MOVIMIENTOS_HIST',
                            'LOGS_RESP_PROC_PCP1_HIST') THEN
            RETURN TRUE;
        -- Tablas particionadas por N�MERO
        ELSIF p_table_name IN ('ORDEN_DETAIL_HIST', 'TRACK_ORDEN_HIST') THEN
            RETURN FALSE;
        ELSE
            RETURN TRUE; -- Por defecto asumir fecha
        END IF;
    END es_tabla_fecha;
    
BEGIN
    DBMS_OUTPUT.PUT_LINE('=== INICIANDO RENOMBRADO DE PARTICIONES (PCPH) ===');
    DBMS_OUTPUT.PUT_LINE('Fecha/Hora: ' || TO_CHAR(SYSTIMESTAMP, 'YYYY-MM-DD HH24:MI:SS'));
    DBMS_OUTPUT.PUT_LINE('Esquema: PCPH');
    DBMS_OUTPUT.PUT_LINE('----------------------------------------');
    
    FOR i IN 1..v_tables.COUNT LOOP
        v_contador_tabla := 0;
        DBMS_OUTPUT.PUT_LINE('Procesando tabla: ' || v_tables(i));
        
        -- Para cada partici�n SYS_P% de la tabla
        FOR part IN (SELECT PARTITION_NAME, PARTITION_POSITION
                     FROM USER_TAB_PARTITIONS
                     WHERE TABLE_NAME = v_tables(i)
                       AND PARTITION_NAME LIKE 'SYS_P%'
                     ORDER BY PARTITION_POSITION) LOOP
            
            BEGIN
                -- Obtener HIGH_VALUE
                v_high_value := get_high_value(v_tables(i), part.PARTITION_NAME);
                
                IF es_tabla_fecha(v_tables(i)) THEN
                    -- Tabla por FECHA: extraer fecha y formatear como YYYYMM
                    v_fecha := extraer_fecha_from_high_value(v_high_value);
                    
                    IF v_fecha IS NOT NULL THEN
                        v_nuevo_nombre := v_tables(i) || '_' || TO_CHAR(v_fecha, 'YYYYMM');
                    ELSE
                        -- Fallback: usar posici�n
                        v_nuevo_nombre := v_tables(i) || '_' || part.PARTITION_POSITION;
                    END IF;
                ELSE
                    -- Tabla por N�MERO: extraer valor num�rico
                    v_valor_numerico := extraer_numero_from_high_value(v_high_value);
                    
                    IF v_valor_numerico IS NOT NULL THEN
                        -- Para ORDEN_DETAIL_HIST: intervalo 1,000,000
                        IF v_tables(i) = 'ORDEN_DETAIL_HIST' THEN
                            v_nuevo_nombre := v_tables(i) || '_' || TO_CHAR(v_valor_numerico - 1000000);
                        -- Para TRACK_ORDEN_HIST: intervalo 100,000
                        ELSIF v_tables(i) = 'TRACK_ORDEN_HIST' THEN
                            v_nuevo_nombre := v_tables(i) || '_' || TO_CHAR(v_valor_numerico - 100000);
                        ELSE
                            v_nuevo_nombre := v_tables(i) || '_' || TO_CHAR(v_valor_numerico);
                        END IF;
                    ELSE
                        -- Fallback: usar posici�n
                        v_nuevo_nombre := v_tables(i) || '_' || part.PARTITION_POSITION;
                    END IF;
                END IF;
                
                -- Renombrar partici�n
                IF part.PARTITION_NAME != v_nuevo_nombre THEN
                    EXECUTE IMMEDIATE 'ALTER TABLE PCPH.' || v_tables(i) || 
                                      ' RENAME PARTITION ' || part.PARTITION_NAME || 
                                      ' TO ' || v_nuevo_nombre;
                    
                    DBMS_OUTPUT.PUT_LINE('  ? Renombrada: ' || RPAD(part.PARTITION_NAME, 25) || 
                                         ' -> ' || v_nuevo_nombre);
                    v_contador_tabla := v_contador_tabla + 1;
                END IF;
                
            EXCEPTION
                WHEN OTHERS THEN
                    DBMS_OUTPUT.PUT_LINE('  ? Error en ' || part.PARTITION_NAME || ': ' || SQLERRM);
            END;
        END LOOP;
        
        DBMS_OUTPUT.PUT_LINE('  ?? Renombradas en ' || v_tables(i) || ': ' || v_contador_tabla);
        v_contador_total := v_contador_total + v_contador_tabla;
        DBMS_OUTPUT.PUT_LINE('----------------------------------------');
    END LOOP;
    
    DBMS_OUTPUT.PUT_LINE('=== PROCESO COMPLETADO ===');
    DBMS_OUTPUT.PUT_LINE('Total particiones renombradas: ' || v_contador_total);
    
    IF v_contador_total = 0 THEN
        DBMS_OUTPUT.PUT_LINE('No se encontraron particiones SYS_P% para renombrar.');
    END IF;
    
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('? ERROR: ' || SQLERRM);
        RAISE;
END RENOMBRAR_PARTICIONES_HIST;
/

-- Verificar que el procedimiento se cre� correctamente
SHOW ERRORS PROCEDURE PCPH.RENOMBRAR_PARTICIONES_HIST;

-- =====================================================
-- 2. Creaci�n del Job programado (cada 6 horas)
-- =====================================================

BEGIN
    BEGIN
        DBMS_SCHEDULER.DROP_JOB(
            job_name => 'PCPH.JOB_RENOMBRAR_PARTICIONES_HIST',
            force    => TRUE
        );
        DBMS_OUTPUT.PUT_LINE('Job anterior eliminado');
    EXCEPTION
        WHEN OTHERS THEN
            IF SQLCODE != -27475 THEN
                DBMS_OUTPUT.PUT_LINE('Nota: ' || SQLERRM);
            END IF;
    END;
    
    DBMS_SCHEDULER.CREATE_JOB (
        job_name        => 'PCPH.JOB_RENOMBRAR_PARTICIONES_HIST',
        job_type        => 'STORED_PROCEDURE',
        job_action      => 'PCPH.RENOMBRAR_PARTICIONES_HIST',
        start_date      => SYSTIMESTAMP,
        repeat_interval => 'FREQ=HOURLY; INTERVAL=6',
        enabled         => TRUE,
        comments        => 'Renombra particiones SYS_Pxxx de tablas PCPH'
    );
    
    DBMS_OUTPUT.PUT_LINE('? Job creado: JOB_RENOMBRAR_PARTICIONES_HIST (cada 6 horas)');
    
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('? Error al crear job: ' || SQLERRM);
        RAISE;
END;
/

-- =====================================================
-- 3. Verificaci�n
-- =====================================================

DECLARE
    v_count NUMBER;
BEGIN
    SELECT COUNT(*)
    INTO v_count
    FROM USER_PROCEDURES
    WHERE OBJECT_NAME = 'RENOMBRAR_PARTICIONES_HIST';
    
    IF v_count > 0 THEN
        DBMS_OUTPUT.PUT_LINE('? Procedimiento instalado correctamente');
    ELSE
        DBMS_OUTPUT.PUT_LINE('? Error: Procedimiento no encontrado');
    END IF;
END;
/

-- Ver job activo
SELECT JOB_NAME, STATE, ENABLED, REPEAT_INTERVAL
FROM USER_SCHEDULER_JOBS
WHERE JOB_NAME = 'JOB_RENOMBRAR_PARTICIONES_HIST';

-- =====================================================
-- Ver estado actual de particiones
-- =====================================================

PROMPT
PROMPT =====================================================
PROMPT ESTADO ACTUAL DE PARTICIONES (PCPH)
PROMPT =====================================================

SELECT TABLE_NAME, PARTITION_NAME, PARTITION_POSITION
FROM USER_TAB_PARTITIONS
WHERE TABLE_NAME IN ('CREDITS_HIST', 'CREDITS_CREDITO_INMEDIATO_HIST', 
                     'ORDEN_DETAIL_HIST', 'ORDEN_HIST', 'DEBITS_HIST', 
                     'TRACK_ORDEN_HIST', 'DATOS_MOVIMIENTOS_HIST', 
                     'LOGS_RESP_PROC_PCP1_HIST')
ORDER BY TABLE_NAME, PARTITION_POSITION;

-- =====================================================
-- PRUEBA MANUAL (descomentar para ejecutar)
-- =====================================================

/*
BEGIN
    PCPH.RENOMBRAR_PARTICIONES_HIST;
END;
/
*/

-- =====================================================
-- FIN DEL SCRIPT PRINCIPAL
-- =====================================================
PROMPT
PROMPT =====================================================
PROMPT INSTALACI�N COMPLETADA
PROMPT =====================================================
PROMPT Esquema: PCPH
PROMPT Procedimiento: RENOMBRAR_PARTICIONES_HIST
PROMPT Job: JOB_RENOMBRAR_PARTICIONES_HIST (cada 6 horas)
PROMPT =====================================================
PROMPT Tablas procesadas:
PROMPT   - CREDITS_HIST (fecha mensual)
PROMPT   - CREDITS_CREDITO_INMEDIATO_HIST (fecha mensual)
PROMPT   - ORDEN_DETAIL_HIST (num�rico por ID_ORDEN)
PROMPT   - ORDEN_HIST (fecha mensual)
PROMPT   - DEBITS_HIST (fecha mensual)
PROMPT   - TRACK_ORDEN_HIST (num�rico por ID_TRACK_ORDEN)
PROMPT   - DATOS_MOVIMIENTOS_HIST (fecha mensual)
PROMPT   - LOGS_RESP_PROC_PCP1_HIST (fecha mensual)
PROMPT =====================================================
PROMPT 
PROMPT Para ejecutar manualmente:
PROMPT EXEC PCPH.RENOMBRAR_PARTICIONES_HIST;
PROMPT =====================================================

-- =====================================================
-- 4. DESINSTALACI�N (OPCIONAL - Ejecutar solo si se necesita eliminar)
-- =====================================================

/*
-- =====================================================
-- SCRIPT DE DESINSTALACI�N
-- Ejecutar este bloque SOLO si desea eliminar el job y el procedimiento
-- =====================================================

PROMPT
PROMPT =====================================================
PROMPT INICIANDO DESINSTALACI�N (PCPH)
PROMPT =====================================================

BEGIN
    -- Eliminar el job programado
    BEGIN
        DBMS_SCHEDULER.DROP_JOB(
            job_name => 'PCPH.JOB_RENOMBRAR_PARTICIONES_HIST',
            force    => TRUE
        );
        DBMS_OUTPUT.PUT_LINE('? Job JOB_RENOMBRAR_PARTICIONES_HIST eliminado');
    EXCEPTION
        WHEN OTHERS THEN
            IF SQLCODE = -27475 THEN
                DBMS_OUTPUT.PUT_LINE('??  El job no exist�a');
            ELSE
                DBMS_OUTPUT.PUT_LINE('? Error al eliminar job: ' || SQLERRM);
            END IF;
    END;
    
    -- Eliminar el procedimiento
    BEGIN
        EXECUTE IMMEDIATE 'DROP PROCEDURE PCPH.RENOMBRAR_PARTICIONES_HIST';
        DBMS_OUTPUT.PUT_LINE('? Procedimiento RENOMBRAR_PARTICIONES_HIST eliminado');
    EXCEPTION
        WHEN OTHERS THEN
            IF SQLCODE = -4043 THEN
                DBMS_OUTPUT.PUT_LINE('??  El procedimiento no exist�a');
            ELSE
                DBMS_OUTPUT.PUT_LINE('? Error al eliminar procedimiento: ' || SQLERRM);
            END IF;
    END;
    
    DBMS_OUTPUT.PUT_LINE('=========================================');
    DBMS_OUTPUT.PUT_LINE('DESINSTALACI�N COMPLETADA');
    DBMS_OUTPUT.PUT_LINE('=========================================');
END;
/

PROMPT
PROMPT =====================================================
PROMPT DESINSTALACI�N COMPLETADA
PROMPT =====================================================
*/

-- =====================================================
-- FIN DEL SCRIPT COMPLETO
-- =====================================================